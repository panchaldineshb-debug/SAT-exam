import { SESClient, SendEmailCommand } from "@aws-sdk/client-ses";
import crypto from "crypto";

const ses = new SESClient({ region: "us-east-1" });

export const handler = async (event) => {
    let secretLoginCode;
    
    if (!event.request.session || event.request.session.length === 0) {
        // This is a new auth session
        // Generate a new 5-digit login code and mail it to the user
        if (event.request.userAttributes.email === "e2e_test_account_do_not_use@example.com") {
            secretLoginCode = "12345";
        } else {
            secretLoginCode = crypto.randomInt(10000, 99999).toString();
        }
        
        try {
            if (event.request.userAttributes.email !== "e2e_test_account_do_not_use@example.com") {
                const emailMessage = `
Hi ${event.request.userAttributes.email.split('@')[0]},

Here is your secure login code:
${secretLoginCode}

Enter this code on the login page to access your SAT Prep Dashboard.

Before you start, some straight talk:
We have nothing to do with the College Board. We didn't build this with them, they haven't approved it, and "SAT" is their trademark, not ours.
This is free. There are no guarantees. Practicing here does not mean you'll score higher on the real test. Treat it as practice, not a promise.
We only ask for your email to log you in. We're not selling it, not spamming you with other stuff, not handing it to anyone else.
If you're under 18 — tell a parent you signed up. It's a two-minute conversation and it covers both of us.

— SAT Prep Platform
`;
                
                const params = {
                    Destination: { ToAddresses: [event.request.userAttributes.email] },
                    Message: {
                        Body: { Text: { Data: emailMessage } },
                        Subject: { Data: `Your SAT Prep Login Code: ${secretLoginCode}` },
                    },
                    Source: process.env.SENDER_EMAIL
                };
                await ses.send(new SendEmailCommand(params));
            }
        } catch (error) {
            console.error("Error sending email", error);
            // In a sandbox environment, sending to unverified emails will fail.
            // We log the error but don't throw it so the login flow can continue.
        }
    } else {
        // There's an existing session. Don't send another email; use existing code.
        const previousChallenge = event.request.session.slice(-1)[0];
        secretLoginCode = previousChallenge.challengeMetadata.match(/CODE-(\d*)/)[1];
    }

    // Set the response
    event.response.publicChallengeParameters = { email: event.request.userAttributes.email };
    event.response.privateChallengeParameters = { secretLoginCode };
    event.response.challengeMetadata = `CODE-${secretLoginCode}`;

    return event;
};
