export const handler = async (event) => {
    const expectedAnswer = event.request.privateChallengeParameters.secretLoginCode;
    const providedAnswer = event.request.challengeAnswer;

    if (providedAnswer === expectedAnswer) {
        event.response.answerCorrect = true;
    } else {
        event.response.answerCorrect = false;
    }

    return event;
};
